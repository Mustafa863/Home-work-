package phonenumber;

import java.util.Scanner;

public class PhoneNumber {

    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        String phoneNumber;
        System.out.println("Please enter a phoner number");
        phoneNumber = input.nextLine();
        if(phoneNumber.length()==10 && phoneNumber.startsWith("077")){
            System.out.println("The format of phone number is from MTN network");
   
        }
            if(phoneNumber.length() == 10 && phoneNumber.startsWith("070")){
                System.out.println("The format of phone number is from AWCC network");  
        }
        if(phoneNumber.length() == 10 && phoneNumber.startsWith("072")){
            System.out.println("The phone number format is from Roshan network");
        }
        if(phoneNumber.length()== 10 && phoneNumber.startsWith("078")){
            System.out.println("The phone number format is from Etislat network");
        }
              if(phoneNumber.length()== 10 && phoneNumber.startsWith("079")){
            System.out.println("The phone number format is from Roshan network");
        }
              if(phoneNumber.length()== 10 && phoneNumber.startsWith("073")){
            System.out.println("The phone number format is from Etislat network");
        }
      
        else{
             System.out.println("The phone number format is incorrect");
        }  
    }}
       
        


    


